# Get VDS health checks
$Output =
	Get-VDPortgroup | Get-View |
	Select Name,
	@{N="VlanOverrideAllowed";E={$_.Config.Policy.VlanOverrideAllowed}},
	@{N="UplinkTeamingOverrideAllowed";E={$_.Config.Policy.UplinkTeamingOverrideAllowed}},
	@{N="SecurityPolicyOverrideAllowed";E={$_.Config.Policy.SecurityPolicyOverrideAllowed}},
	@{N="IpfixOverrideAllowed";E={$_.Config.Policy.IpfixOverrideAllowed}},
	@{N="BlockOverrideAllowed";E={$_.Config.Policy.BlockOverrideAllowed}},
	@{N="ShapingOverrideAllowed";E={$_.Config.Policy.ShapingOverrideAllowed}},
	@{N="VendorConfigOverrideAllowed";E={$_.Config.Policy.VendorConfigOverrideAllowed}},
	@{N="TrafficFilterOverrideAllowed";E={$_.Config.Policy.TrafficFilterOverrideAllowed}},
	@{N="PortConfigResetAtDisconnect";E={$_.Config.Policy.PortConfigResetAtDisconnect}}
$Output | ConvertTo-Csv -NoTypeInformation