$server=$args[0]
$user=$args[1]
$cred=$args[2]
#$cred -replace '[*\\~;(%?.:@/&]', '`$&' | out-null
$viServer=Connect-VIServer -Server $server -User $user -Password $cred
$viServer.isConnected