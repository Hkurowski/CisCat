# List of lockdown users with an exception for a specific host
Param($vmHost)
$myhost = Get-VMHost $vmHost | Get-View
$lockdown = Get-View $myhost.ConfigManager.HostAccessManager
$lockdown.QueryLockdownExceptions()